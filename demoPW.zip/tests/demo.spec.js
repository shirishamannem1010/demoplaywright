const {test, expect}=require("@playwright/test");
test('Demo Test', async({page})=>{
    
   await page.goto('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
    await page.waitForTimeout(5000);
await page.locator('input[name="username"]').fill("Admin");

await page.waitForTimeout(3000);
await page.locator('input[name="password"]').fill("admin123");
await page.waitForTimeout(3000);

// await page.locator('//button[text()=' Login ']').click();

await page.locator('//button[text()=" Login "]').click();

// await page.waitForTimeout(5000);

   // await expect(page).toHaveTitle('Google');
})
